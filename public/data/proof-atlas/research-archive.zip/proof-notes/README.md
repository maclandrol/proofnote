# Proof Notes analysis data

The paper index, every public report and the detailed mathematical notes. `data/scanned-papers.json` indexes the papers; `data/reviews/` contains their public claim checks. Each assessment concerns the selected argument. The analyses, explanations and checks were produced by GPT 6.1 Sol, Claude and DeepSeek; most have not been verified by a human.

Run the standalone arithmetic witnesses with Python 3 from this directory:

```sh
python3 data/reproduce.py
python3 data/reproduce-belief.py
python3 data/reproduce-neurips-2026.py
```

They use only the Python standard library. The results check the stated constructions; they do not reproduce training runs or benchmarks. `MANIFEST.json` lists SHA-256 hashes of the included files. Source documents retain their original rights and are not included.

Browse the [notes](https://proofnote.enoutahi.com). The site's source is in the [repository](https://github.com/maclandrol/proofnote).
